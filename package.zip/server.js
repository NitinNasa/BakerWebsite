/*global.fetch = (...args) =>
  import('node-fetch').then(({ default: fetch }) => fetch(...args));

global.Blob = (await import('fetch-blob')).Blob;
global.FormData = (await import('formdata-node')).FormData; */

const express = require('express');
const cors = require('cors');
const { HfInference } = require('@huggingface/inference');
const OpenAI = require( "openai");

const app = express();
app.use(cors());
app.use(express.json());

const hf = new HfInference('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');

const client = new OpenAI({
  apiKey: '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',
  baseURL: "https://router.huggingface.co/v1"
});
app.post('/api/sentiment', async (req, res) => {
  try {
    const result = await hf.textClassification({
      model: 'distilbert-base-uncased-finetuned-sst-2-english',
      inputs: req.body.text
    });

    res.json(result);
  } catch (error) {
    console.error('HF ERROR:', error);
    res.status(500).json({ error: error.message });
  }
});

app.post("/api/generate-email", async (req, res) => {
  try {
    const { purpose, tone, recipient } = req.body;

    const completion = await client.chat.completions.create({
      model: "meta-llama/Meta-Llama-3-8B-Instruct",
      messages: [
        {
          role: "system",
          content: "You are an assistant that writes clear and professional emails."
        },
        {
          role: "user",
          content: `
Write a ${tone} email.

Recipient: ${recipient}
Purpose: ${purpose}
          `
        }
      ],
      temperature: 0.7,
      max_tokens: 300
    });

    res.json({
      email: completion.choices[0].message.content
    });

  } catch (error) {
    console.error("HF EMAIL ERROR:", error);
    res.status(500).json({
      error: "Email generation failed",
      details: error.message
    });
  }
});



app.listen(3000, () => {
  console.log('Backend running on http://localhost:3000');
});
