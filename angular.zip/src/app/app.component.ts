import { Component } from '@angular/core';
import { AiService } from './services/ai.service';
import { ArtificalLearnService } from './services/artifical-learn.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})
export class AppComponent {
  userText: string = '';
  result:any = [];
  selectedFramework: string = 'TextSentiment'; // default selection
  emailPrompt = '';
  tone = 'professional';
  generatedEmail = '';
  loading = false;
  purpose = '';
  recipient = '';
  

  constructor(private aiService: ArtificalLearnService) {}

 /* analyze() {
    debugger;
    this.result = this.aiService.analyzeSentiment1(this.userText);
    
  } */

  analyze() {
    this.aiService.analyzeSentiment1(this.userText).subscribe((response: any[]) => {
      const result = response[0];
      console.log(result);
    
      this.result = `${result.label} (${(result.score * 100).toFixed(2)}%)`;
    });
  } 

  generateEmail() {
    this.loading = true;
    this.aiService.generateEmail({
      purpose: this.purpose,
      tone: this.tone,
      recipient: this.recipient
    }).subscribe(res => {
      this.generatedEmail = res.email;
    });
  }
  //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
}
