import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AiService {

  analyzeSentiment(text: string): string {
    const lower = text.toLowerCase();

    if (lower.includes('good') || lower.includes('happy')) {
      return 'Positive 😊';
    } else if (lower.includes('bad') || lower.includes('sad')) {
      return 'Negative 😞';
    }
    return 'Neutral 😐';
  }
}
