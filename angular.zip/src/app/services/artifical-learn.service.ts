//import { Injectable } from '@angular/core';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ArtificalLearnService {

  private apiUrl =
    'https://api-inference.huggingface.co/models/distilbert-base-uncased-finetuned-sst-2-english';

  private apiKey = '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';

  constructor(private http: HttpClient) {}

  analyzeSentiment1(text: string):any {
    return this.http.post(
      'http://localhost:3000/api/sentiment',
      { text }
    );
  }

  generateEmail(payload: any) {
    return this.http.post<any>('http://localhost:3000/api/generate-email', payload);
  }
}
