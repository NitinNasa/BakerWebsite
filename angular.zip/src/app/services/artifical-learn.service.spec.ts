import { TestBed } from '@angular/core/testing';

import { ArtificalLearnService } from './artifical-learn.service';

describe('ArtificalLearnService', () => {
  let service: ArtificalLearnService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ArtificalLearnService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
